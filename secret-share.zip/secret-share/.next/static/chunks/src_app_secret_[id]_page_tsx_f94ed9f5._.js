(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_81d8eb78._.js",
  "static/chunks/src_app_secret_[id]_page_tsx_19da7130._.js"
],
    source: "dynamic"
});
